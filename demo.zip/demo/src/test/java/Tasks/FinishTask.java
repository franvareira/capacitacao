package Tasks;

import org.openqa.selenium.WebDriver;

import PageObjects.FinishPage;
import Validations.FinishValidation;
import Validations.GenericValidation;
import Validations.LoginValidation;
import framework.Browser.Waits;

public class FinishTask {
	
	
	private WebDriver driver;
	
	private FinishPage finishPage;
	
	private GenericValidation genericValidation;
	
	private FinishValidation finishValidation;
	
	private Waits wait;
	
	private LoginValidation loginValidation;
	
    
	public FinishTask(WebDriver driver) {
		
		this.driver = driver;
		finishPage = new FinishPage(driver);
		genericValidation = new GenericValidation(driver);
		finishValidation = new FinishValidation(driver);
		wait = new Waits(driver);
		loginValidation = new LoginValidation(driver);
		
	}
	
	
   public void finalizarCompra() {
	   
	   
	   genericValidation.validationPageFinish();
	   finishValidation.validaMensagemCompra();
	   finishPage.getMenuLogoutButton().click();
	   wait.loadElement(finishPage.getLogoutLink());
	   finishPage.getLogoutLink().click();
	   loginValidation.validationLoginPage();
	   
	   
	   
   }
	
	
	
	
}
