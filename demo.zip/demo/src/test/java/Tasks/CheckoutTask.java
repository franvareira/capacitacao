package Tasks;

import org.openqa.selenium.WebDriver;

import PageObjects.CheckoutPage;
import Validations.CheckoutValidation;
import Validations.GenericValidation;
import framework.Utils.FakersGeneration;

public class CheckoutTask {
	
	private WebDriver driver;
	
	private CheckoutPage checkoutPage;
	
	private FakersGeneration fakers;
	
	private GenericValidation genericValidation;
	
	private CheckoutValidation checkoutValidation;
	
	
	public CheckoutTask(WebDriver driver) {
		
		this.driver = driver;
		checkoutPage = new CheckoutPage(driver);
		fakers = new FakersGeneration(driver);
		genericValidation = new GenericValidation(driver);
		checkoutValidation = new CheckoutValidation(driver);
			
	}
	
	public void preencherForm()  {
		
		checkoutPage.getFirstNameTextField().sendKeys(fakers.getFirstName());
		checkoutPage.getLastNameTextField().sendKeys(fakers.getLastName());
		checkoutPage.getZipCodeTextField().sendKeys(fakers.getZipCode());
		checkoutValidation.validaForm();
		checkoutPage.getContinueButton().click();
		genericValidation.validationPageCheckoutOverview();
		checkoutPage.getFinishButton().click();
		
	
	}

}
