package Tasks;

import org.openqa.selenium.WebDriver;

import PageObjects.HomePage;
import Validations.GenericValidation;
import Validations.LoginValidation;

public class HomeTask {
	
	
	private WebDriver driver;
	
	private HomePage homepage;
	
	private LoginValidation loginValidation;
	
	private GenericValidation genericValidation;
	
	public HomeTask(WebDriver driver) {
		
		this.driver = driver;
		homepage = new HomePage(this.driver);
		loginValidation = new LoginValidation(driver);
		genericValidation = new GenericValidation(driver);
		
	}
	
	
	public void efetuarLogin() {
		
		loginValidation.validationLoginPage();
	    homepage.getUserNameTextField().sendKeys("standard_user");
	    homepage.getPasswordTextField().sendKeys("secret_sauce");
	    homepage.getLoginButton().click();
	    genericValidation.validationPageProducts();

	}
	
	public void efetuarLoginParametrizado(String user, String password) {
		
		loginValidation.validationLoginPage();
	    homepage.getUserNameTextField().sendKeys(user);
	    homepage.getPasswordTextField().sendKeys(password);
	    homepage.getLoginButton().click();
	    genericValidation.validationPageProducts();

	}
	
	

}
