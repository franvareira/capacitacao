package Tasks;

import org.openqa.selenium.WebDriver;

import PageObjects.CartPage;
import PageObjects.SelectProductPage;
import Validations.GenericValidation;
import framework.Browser.Waits;

public class SelectProductTask {
	
	
	private WebDriver driver;
	
	private SelectProductPage selectProductPage;
	
	private CartPage cartPage;
	
	private Waits wait;
	
	private GenericValidation genericValidtion;
	
	public SelectProductTask(WebDriver driver) {
		
		
		this.driver = driver;
		selectProductPage = new SelectProductPage(driver);	
		cartPage = new CartPage(this.driver);
		wait = new Waits(this.driver);
		genericValidtion = new GenericValidation(driver);
		
	}
	
	public void selecionarProduto() {
		
		selectProductPage.getProdutoAddButton().click();
		selectProductPage.getCartButton().click();
		genericValidtion.validationPageCart();
		genericValidtion.validationPageCartProduct();
		cartPage.getCheckoutButton().click();
		genericValidtion.validationPageCheckout();
		
	}
	

}
