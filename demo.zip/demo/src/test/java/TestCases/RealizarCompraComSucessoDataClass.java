package TestCases;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Tasks.CheckoutTask;
import Tasks.FinishTask;
import Tasks.HomeTask;
import Tasks.SelectProductTask;
import framework.TestBase;
import framework.Report.Report;
import framework.Report.ReportType;
import framework.Report.Screenshot;

public class RealizarCompraComSucessoDataClass extends TestBase{
	
	  private WebDriver driver = this.getDriver();
	  
	 HomeTask homeTask = new HomeTask(driver);
	 
	 SelectProductTask selecProductTask = new SelectProductTask(driver);
	 
	 CheckoutTask checkoutTask = new CheckoutTask(driver);
	 
	 FinishTask finishTask = new FinishTask(driver);
	
	
	  
	  @ParameterizedTest
	  @MethodSource("framework.Utils.DataClass#loginTestData")
	  public void realizarCompra(String user, String password) {
		  
		  try {
			  Report.createTest("Realizar Compra com Sucesso Parametrizado DataClass", ReportType.SINGLE);
			  homeTask.efetuarLoginParametrizado(user, password);
			  selecProductTask.selecionarProduto();
			  checkoutTask.preencherForm();
			  finishTask.finalizarCompra();
			  
		  }catch (Exception e) {
			  
			  Report.log(Status.FAIL, e.getMessage(), Screenshot.capture(driver));
		}
		
		  
	
	  }
	
	

}
