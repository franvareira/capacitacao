package TestCases;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Tasks.CheckoutTask;
import Tasks.FinishTask;
import Tasks.HomeTask;
import Tasks.SelectProductTask;
import framework.TestBase;
import framework.Report.Report;
import framework.Report.ReportType;
import framework.Report.Screenshot;

public class RealizarCompraComSucesso extends TestBase{
	
	  private WebDriver driver = this.getDriver();
	  
	 HomeTask homeTask = new HomeTask(driver);
	 
	 SelectProductTask selecProductTask = new SelectProductTask(driver);
	 
	 CheckoutTask checkoutTask = new CheckoutTask(driver);
	 
	 FinishTask finishTask = new FinishTask(driver);
	
	
	  
	  @Test	
	  @Tag("regressao")
	  public void realizarCompra() {
		  
		 try {
	          
			  Report.createTest("Realizar compra com Sucesso", ReportType.SINGLE);
			  homeTask.efetuarLogin();
			  selecProductTask.selecionarProduto();
			  checkoutTask.preencherForm();
			  finishTask.finalizarCompra();
	 
	 
	 
		  }catch (Exception e) {
	
		       Report.log(Status.FAIL, e.getMessage(), Screenshot.capture(driver));
	
		  }
	  }
}