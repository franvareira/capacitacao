package TestCases;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Tasks.CheckoutTask;
import Tasks.FinishTask;
import Tasks.HomeTask;
import Tasks.SelectProductTask;
import framework.TestBase;
import framework.Report.Report;
import framework.Report.ReportType;
import framework.Report.Screenshot;

public class RealizarCompraComSucessoCSV extends TestBase{
	
	  private WebDriver driver = this.getDriver();
	  
	 HomeTask homeTask = new HomeTask(driver);
	 
	 SelectProductTask selecProductTask = new SelectProductTask(driver);
	 
	 CheckoutTask checkoutTask = new CheckoutTask(driver);
	 
	 FinishTask finishTask = new FinishTask(driver);
	
	
	  
	  @ParameterizedTest
	  @CsvFileSource(resources = "/CSV/users.csv", numLinesToSkip = 1)
	  @Tag("regressao")
	  @Tag("alternativo")
	  public void realizarCompra(String user, String password) {
		  
		  try {
			  
			  Report.createTest("Realizar Compra com Sucesso Parametrizado CSV", ReportType.GROUP);
			  Report.createStep("Login");
			  homeTask.efetuarLoginParametrizado(user, password);
			  Report.createStep("Comprar Produto");
			  selecProductTask.selecionarProduto();
			  checkoutTask.preencherForm();
			  Report.createStep("Finalizar Compra");
			  finishTask.finalizarCompra();
			  
			  
		  }catch (Exception e) {
			  
			  Report.log(Status.FAIL, e.getMessage(), Screenshot.capture(driver));
		}
		
		 
	
	  }
	
	

}
