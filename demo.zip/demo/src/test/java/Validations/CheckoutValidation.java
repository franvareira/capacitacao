package Validations;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import PageObjects.CheckoutPage;
import framework.Report.Report;
import framework.Report.Screenshot;

public class CheckoutValidation {
	
	
	private WebDriver driver;
    
	private CheckoutPage checkoutPage;
	
	public CheckoutValidation(WebDriver driver) {
		
		this.driver = driver;
		checkoutPage = new CheckoutPage(driver);
	}
	
	
	public void validaForm() {
		
		try {
			String primeiroNome = checkoutPage.getFirstNameTextField().getAttribute("value").toString();
			Assertions.assertFalse(checkoutPage.getFirstNameTextField().getAttribute("value").equalsIgnoreCase(" "));
			Report.log(Status.PASS, "Formulário Preenchido corretamente", Screenshot.captureBase64(driver));
			Report.log(Status.INFO, "Info-primeiro nome: " + primeiroNome);
			
		}catch (Exception e) {
			
			Report.log(Status.FAIL, e.getMessage(), Screenshot.captureBase64(driver));
		}
		
		
	}
	
	
}
