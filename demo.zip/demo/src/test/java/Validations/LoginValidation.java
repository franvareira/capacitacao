package Validations;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import PageObjects.HomePage;
import framework.Browser.Waits;
import framework.Report.Report;
import framework.Report.Screenshot;

public class LoginValidation {
	
	private WebDriver driver;
	
	
	private HomePage homePage;
	
	private Waits wait;
	
	
	public LoginValidation (WebDriver driver) {
		
		this.driver = driver;
		homePage = new HomePage(driver);
		wait= new Waits(driver);
		
	}
	
	
	public void validationLoginPage() {
		
		try {
			
			wait.loadElement(homePage.getLogoTitle());
			Assertions.assertTrue(homePage.getLogoTitle().isDisplayed());
			Report.log(Status.PASS, "Página de Login Acessada com Sucesso", Screenshot.capture(driver));
			
		}catch (Exception e) {
			
			Report.log(Status.FAIL, e.getMessage(), Screenshot.capture(driver));
		}

	}
	
	

}
