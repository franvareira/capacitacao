package Validations;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import PageObjects.FinishPage;
import framework.Report.Report;
import framework.Report.Screenshot;

public class FinishValidation {
	
	private WebDriver  driver;
	
	private FinishPage finishPage;
	
	public FinishValidation(WebDriver driver) {
		
		this.driver = driver;
		finishPage = new FinishPage(driver);
	}
	
	
	public void validaMensagemCompra() {
		
		try {
			
			String label = finishPage.getFinishTextTitle().getText();
			Assertions.assertEquals("THANK YOU FOR YOUR ORDER", label);
			Report.log(Status.PASS, "Compra finalizada com Sucesso", Screenshot.captureBase64(driver));
			
		}catch (Exception e) {
			
			Report.log(Status.FAIL, e.getMessage(), Screenshot.captureBase64(driver));
			
		}
        
	}

}
