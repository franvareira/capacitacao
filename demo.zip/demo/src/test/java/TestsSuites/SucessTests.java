package TestsSuites;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

import TestCases.RealizarCompraComSucesso;
import TestCases.RealizarCompraComSucessoDataClass;

@Suite
@SelectClasses({RealizarCompraComSucesso.class, RealizarCompraComSucessoDataClass.class})
public class SucessTests {

}
