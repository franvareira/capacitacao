package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import framework.Browser.Waits;

public class SelectProductPage {
	
	
	private WebDriver driver;
	
	private Waits wait;
	
	public SelectProductPage(WebDriver driver) {
		
		this.driver = driver;
		wait = new Waits(this.driver);
		
	}
	
	public WebElement getProdutoAddButton() {
		
		
		return driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
	
	}
	
	public WebElement getCartButton() {
		
		return wait.visibilityOfElement(By.xpath("//div[@id='shopping_cart_container']/a[@class='shopping_cart_link']"));
		
	}
	
	
	
	
	

}
