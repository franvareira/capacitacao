package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import framework.Browser.Waits;

public class HomePage {
	
	
	private WebDriver driver;
	
	private Waits wait;
	
    public HomePage(WebDriver driver) {
    	
    	
    	this.driver = driver;
    	wait = new Waits(this.driver);
    	
    }
	
    
    public WebElement getUserNameTextField() {
    	
    	
    	/*WebElement username = driver.findElement(By.id("user-name"));
    	
    	return username;*/
    	
    	return wait.visibilityOfElement(By.id("user-name"));

    	
    }
    
    public WebElement getPasswordTextField() {
    	
    	
    	return driver.findElement(By.id("password"));
    	
    	
    }
    
    public WebElement getLoginButton() {
    	
    	
    	
    	return driver.findElement(By.id("login-button"));
    		
    }
    
    public WebElement getLogoTitle() {
    	
    	
    	return wait.visibilityOfElement(By.className("login_logo"));
    	
    }
    


}
