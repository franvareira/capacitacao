package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import framework.Browser.Waits;

public class CheckoutPage {
	
	
	private WebDriver driver;
	
	private Waits wait;
	
    public CheckoutPage (WebDriver driver) {
    	
    	this.driver = driver;
    	wait = new Waits(driver);
    	
    }
    
    
    public WebElement getFirstNameTextField() {
    	
    	return driver.findElement(By.id("first-name"));
    }
    
    public WebElement getLastNameTextField() {
    	
    	return driver.findElement(By.id("last-name"));
    }
    
    public WebElement getZipCodeTextField() {
    	
    	return driver.findElement(By.id("postal-code"));
    }
    
    public WebElement getContinueButton() {
    	
    	return driver.findElement(By.id("continue"));
    }
    
    public WebElement getFinishButton() {
    	
    	return driver.findElement(By.id("finish"));
    }
    
	
}
