package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import framework.Browser.Waits;

public class FinishPage {
	
	private WebDriver driver;
	private Waits wait;
	
	public FinishPage(WebDriver driver) {
		
		this.driver = driver;
		wait = new Waits(driver);
		
	}
	
	public WebElement getFinishTextTitle() {
		
		return wait.visibilityOfElement(By.xpath("//div[@class='checkout_complete_container']/h2[@class='complete-header']"));
	}
	
	public WebElement getMenuLogoutButton() {
		
		return driver.findElement(By.id("react-burger-menu-btn"));
	}
	
	public WebElement getLogoutLink() {
		
		return driver.findElement(By.id("logout_sidebar_link"));
		
		
	}
}
