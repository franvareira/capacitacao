package framework.Utils;

public class DataClass {
	
	
	public static Object [] [] loginTestData(){
		
		return new Object  [][] {{"standard_user","secret_sauce"}};
			
	}
	
   public static Object [] [] loginTestData2(){
		
		return new Object  [][] {
			{"locked_out_user","secret_sauce"},
			{"standard_user","secret_sauce"}
			
		};
			
	}
	
	

}
