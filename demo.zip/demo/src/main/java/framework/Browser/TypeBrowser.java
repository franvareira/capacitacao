package framework.Browser;

public enum TypeBrowser {
	
	
	CHROME,
	FIREFOX,
	IE,
	EDGE,
	HEADLESS;
	

}
