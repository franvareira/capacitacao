package framework.Report;

public enum ReportType {
	
	
	SINGLE,
	GROUP;

}
